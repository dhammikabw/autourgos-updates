# VSL (vessel firmware core)
