from shared.constants import SHARED_CONSTANT


def main() -> None:
    print(SHARED_CONSTANT)


if __name__ == "__main__":
    main()

